#!/usr/bin/env python

import os

os.system('appium -a 192.168.4.153 -p 4723 --no-reset')