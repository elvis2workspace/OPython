Robot Framework Demo
====================

`Robot Framework`__ is a generic open source test automation framework.
This demo introduces the basic Robot Framework test data syntax, how tests
are executed, how generated logs and reports look like, and how to create
custom test libraries.

See `project wiki`__ for more information about running the demo, viewing
results, etc. You can also view the tests and generated results through
the wiki without running the demo yourself.

__ http://robotframework.org
__ https://bitbucket.org/robotframework/robotdemo/wiki/Home
