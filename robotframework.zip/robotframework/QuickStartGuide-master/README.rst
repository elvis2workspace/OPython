Robot Framework Quick Start Guide
=================================

*Robot Framework Quick Start Guide* introduces the most important `Robot
Framework <http://robotframework.org>`_ features. You can simply browse
through it and look at the examples, but you can also use the guide as
an executable demo.

The guide itself is in `<QuickStart.rst>`_ file. It replaces the old version
still available on the `old project pages`__.

Copyright © Nokia Solutions and Networks. Licensed under the
`Creative Commons Attribution 3.0 Unported`__ license.

__ http://code.google.com/p/robotframework/wiki/QuickStartGuide
__ http://creativecommons.org/licenses/by/3.0/
